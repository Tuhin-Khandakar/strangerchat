<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Terms of Service | STRNGR</title>
    <link rel="stylesheet" href="styles/main.css" />
    <!-- Dynamic Favicons -->
    <link rel="icon" type="image/png" href="logo.png" media="(prefers-color-scheme: light)" />
    <link rel="icon" type="image/png" href="logo_dark.png" media="(prefers-color-scheme: dark)" />
    <link rel="apple-touch-icon" href="logo.png" />
    <script type="module" src="./scripts/theme-init.js" nonce="__NONCE__"></script>
    <style>
      body {
        background: var(--bg-light);
        padding: 40px 20px;
        overflow-y: auto;
        line-height: 1.6;
      }

      .content-card {
        max-width: 800px;
        margin: 0 auto;
        background: var(--bg-white);
        padding: 48px;
        border-radius: 24px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
      }

      .header-logo {
        display: flex;
        align-items: center;
        gap: 12px;
        text-decoration: none;
        margin-bottom: 40px;
        color: var(--text-dark);
        font-weight: 700;
        font-size: 1.25rem;
      }

      .header-logo img {
        height: 32px;
      }

      h1 {
        font-size: 2.5rem;
        margin-bottom: 24px;
        letter-spacing: -0.02em;
      }

      h2 {
        font-size: 1.5rem;
        margin-top: 32px;
        margin-bottom: 12px;
        color: var(--text-dark);
      }

      p,
      li {
        color: var(--text-muted);
        margin-bottom: 16px;
      }

      ul {
        padding-left: 20px;
        margin-bottom: 24px;
      }

      .back-link {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        color: var(--primary);
        text-decoration: none;
        font-weight: 600;
        margin-bottom: 24px;
      }
    </style>
  </head>

  <body>
    <main>
      <div class="content-card">
        <a href="/" class="header-logo">
          <img src="logo.png" alt="STRNGR" class="logo-light" />
          <img src="logo_dark.png" alt="STRNGR" class="logo-dark" />
          <span>STRNGR</span>
        </a>
        <a href="/" class="back-link">← Back to Chat</a>
        <h1>Terms of Service</h1>

        <section>
          <h2>1. Eligibility</h2>
          <p>
            You must be at least 18 years old to use STRNGR. By using this service, you represent
            and warrant that you meet this age requirement.
          </p>
        </section>

        <section>
          <h2>2. Prohibited Conduct</h2>
          <p>We focus on real conversations, not chaos. You agree not to use the service for:</p>
          <ul>
            <li>Harassment, bullying, or stalking.</li>
            <li>Distribution of spam or malicious software.</li>
            <li>Sharing illegal or sexually explicit content.</li>
            <li>Impersonating others or collecting personal information.</li>
          </ul>
        </section>

        <section>
          <h2>3. Moderation and Safety</h2>
          <p>
            We reserve the right to moderate chats and issue temporary or permanent bans based on
            user reports or automated filters to keep the community safe. Bans are enforced via
            anonymized identifiers.
          </p>
        </section>

        <section>
          <h2>4. Privacy and Data</h2>
          <p>
            We do not sell your data. Conversations are ephemeral and not stored permanently. Please
            refer to our Privacy Policy for more details.
          </p>
        </section>

        <section>
          <h2>5. Disclaimers</h2>
          <p>
            STRNGR is provided "as is" without warranties of any kind. Use the service at your own
            risk. We are not responsible for the behavior of strangers you meet on the platform.
          </p>
        </section>
      </div>
    </main>
  </body>
</html>
