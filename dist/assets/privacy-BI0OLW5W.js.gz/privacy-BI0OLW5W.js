<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Privacy Policy | STRNGR</title>
    <link rel="stylesheet" href="styles/main.css" />
    <!-- Dynamic Favicons -->
    <link rel="icon" type="image/png" href="logo.png" media="(prefers-color-scheme: light)" />
    <link rel="icon" type="image/png" href="logo_dark.png" media="(prefers-color-scheme: dark)" />
    <link rel="apple-touch-icon" href="logo.png" />
    <script type="module" src="./scripts/theme-init.js" nonce="__NONCE__"></script>
    <style>
      body {
        background: var(--bg-light);
        padding: 40px 20px;
        overflow-y: auto;
        line-height: 1.6;
      }

      .content-card {
        max-width: 800px;
        margin: 0 auto;
        background: var(--bg-white);
        padding: 48px;
        border-radius: 24px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
      }

      .header-logo {
        display: flex;
        align-items: center;
        gap: 12px;
        text-decoration: none;
        margin-bottom: 40px;
        color: var(--text-dark);
        font-weight: 700;
        font-size: 1.25rem;
      }

      .header-logo img {
        height: 32px;
      }

      h1 {
        font-size: 2.5rem;
        margin-bottom: 24px;
        letter-spacing: -0.02em;
      }

      h2 {
        font-size: 1.5rem;
        margin-top: 32px;
        margin-bottom: 12px;
        color: var(--text-dark);
      }

      p,
      li {
        color: var(--text-muted);
        margin-bottom: 16px;
      }

      .back-link {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        color: var(--primary);
        text-decoration: none;
        font-weight: 600;
        margin-bottom: 24px;
      }
    </style>
  </head>

  <body>
    <main>
      <div class="content-card">
        <a href="/" class="header-logo">
          <img src="logo.png" alt="STRNGR" class="logo-light" />
          <img src="logo_dark.png" alt="STRNGR" class="logo-dark" />
          <span>STRNGR</span>
        </a>
        <a href="/" class="back-link">← Back to Chat</a>
        <h1>Privacy Policy</h1>

        <section>
          <h2>1. Data Minimization</h2>
          <p>
            STRNGR is built for anonymity. We do not require sign-ups, email addresses, or any
            personal profiles. Our goal is to connect you with strangers without noise, pressure, or
            exposure.
          </p>
        </section>

        <section>
          <h2>2. IP Hashing</h2>
          <p>
            To ensure safety and manage reports, we use anonymized identifiers derived from IP
            addresses. We do not store raw IP addresses in our permanent database.
          </p>
        </section>

        <section>
          <h2>3. Ephemeral Conversations</h2>
          <p>
            Your conversations are real-time and ephemeral. They are not stored permanently on our
            servers after the session ends, except in cases of reported abuse which may be
            temporarily reviewed for safety moderation.
          </p>
        </section>

        <section>
          <h2>4. No Data Selling</h2>
          <p>
            We do not sell your data. We do not use tracking algorithms for advertising or
            behavioral targeting. STRNGR is designed to be a clean, direct communication platform.
          </p>
        </section>

        <section>
          <h2>5. Cookies and Storage</h2>
          <p>
            We use minimal technical storage only as necessary to maintain your active chat session.
            No third-party tracking cookies are used.
          </p>
        </section>
      </div>
    </main>
  </body>
</html>
